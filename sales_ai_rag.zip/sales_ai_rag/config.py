from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env in development
load_dotenv(dotenv_path=Path(__file__).with_suffix('.env'), override=False)

# Google Generative AI
GEMINI_MODEL: str = "gemini-1.5-flash"
GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY")  # required
EMBED_MODEL: str = "models/embedding-001"

# Qdrant
QDRANT_URL: str = os.getenv("QDRANT_URL")
QDRANT_API_KEY: str = os.getenv("QDRANT_API_KEY")
QDRANT_COLLECTION: str = os.getenv("QDRANT_COLLECTION", "sales_ai_store")

# Chunking
CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", 450))
CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", 50))